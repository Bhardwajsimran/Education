package com.example.translate.classes


data class WordFin(val word: String, val meaning: String) {

}